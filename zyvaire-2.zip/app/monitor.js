"use strict";

const channels = [
  { name: "N3on", slug: "n3on" },
  { name: "Cuffem", slug: "cuffem" },
  { name: "Adin Ross", slug: "adinross" },
];
const storageKey = "zyvaire.kick.flags.v1";
const streamList = document.querySelector("#streams");
const flagList = document.querySelector("#flags");
const status = document.querySelector("#status");
const template = document.querySelector("#stream");
const channelUrl = (slug) => new URL(slug, "https://kick.com/").href;

function loadFlags() {
  try {
    const saved = JSON.parse(localStorage.getItem(storageKey) || "[]");
    return Array.isArray(saved) ? saved.filter((flag) =>
      flag && channels.some((channel) => channel.slug === flag.slug) &&
      Number.isFinite(Date.parse(flag.time))) : [];
  } catch {
    return [];
  }
}

let flags = loadFlags();

function renderFlags() {
  flagList.replaceChildren();
  if (!flags.length) {
    const empty = document.createElement("li");
    empty.textContent = "No moments flagged yet.";
    flagList.append(empty);
    return;
  }
  for (const flag of flags) {
    const channel = channels.find(({ slug }) => slug === flag.slug);
    const item = document.createElement("li");
    const link = document.createElement("a");
    link.href = channelUrl(channel.slug);
    link.dataset.kick = channel.slug;
    link.target = "_blank";
    link.rel = "noopener noreferrer";
    link.textContent = channel.name;
    item.append(link, " · ", new Date(flag.time).toLocaleString());
    flagList.append(item);
  }
}

const cards = channels.map((channel) => {
  const card = template.content.cloneNode(true);
  card.querySelector("h2").textContent = channel.name;
  const player = document.createElement("iframe");
  player.title = channel.name + " on Kick";
  player.allow = "autoplay; fullscreen";
  card.querySelector(".player").append(player);
  const audio = card.querySelector(".audio");
  const clip = card.querySelector(".primary");
  clip.href = channelUrl(channel.slug);
  clip.dataset.kick = channel.slug;
  clip.setAttribute("aria-label", "Open " + channel.name + " on Kick to clip");
  card.querySelector(".flag").addEventListener("click", () => {
    const next = [{ slug: channel.slug, time: new Date().toISOString() }, ...flags].slice(0, 500);
    try {
      localStorage.setItem(storageKey, JSON.stringify(next));
      flags = next;
      renderFlags();
      status.textContent = "Moment flagged for " + channel.name + ".";
    } catch {
      status.textContent = "This browser could not save the flag.";
    }
  });
  streamList.append(card);
  return { channel, player, audio };
});

function setAudio(card, audible) {
  const playerUrl = new URL(card.channel.slug, "https://player.kick.com/");
  playerUrl.searchParams.set("autoplay", "true");
  playerUrl.searchParams.set("muted", String(!audible));
  card.player.src = playerUrl.href;
  card.audio.setAttribute("aria-pressed", String(audible));
  card.audio.textContent = audible ? "Mute audio" : "Enable audio";
}

for (const card of cards) {
  setAudio(card, false);
  card.audio.addEventListener("click", () => {
    const audible = card.audio.getAttribute("aria-pressed") === "true";
    for (const other of cards) {
      if (other !== card && other.audio.getAttribute("aria-pressed") === "true") {
        setAudio(other, false);
      }
    }
    setAudio(card, !audible);
  });
}

renderFlags();

document.addEventListener("click", async (event) => {
  const link = event.target.closest("a[data-kick]");
  if (!link || !window.pywebview?.api) return;
  event.preventDefault();
  try {
    await window.pywebview.api.open_kick(link.dataset.kick);
  } catch {
    status.textContent = "Could not open the Kick window. Try again or open the channel in your browser.";
  }
});
