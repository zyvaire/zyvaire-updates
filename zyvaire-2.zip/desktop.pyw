from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import ctypes
import os
from threading import Lock, Thread
from traceback import format_exc

import webview


ROOT = Path(__file__).resolve().parent
PROFILE = Path(os.environ["LOCALAPPDATA"]) / "Zyvaire" / "WebView2"
ADDRESS = "127.0.0.1"
PORT = 8752
CHANNELS = {"": "Sign in", "n3on": "N3on", "cuffem": "Cuffem", "adinross": "Adin Ross"}


class LocalAssets(SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.headers.get("Host") != f"{ADDRESS}:{PORT}":
            self.send_error(400)
            return
        super().do_GET()

    def end_headers(self):
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; frame-src https://player.kick.com; "
            "base-uri 'none'; frame-ancestors 'none'",
        )
        super().end_headers()

    def log_message(self, *_args):
        pass


class KickWindows:
    def __init__(self):
        self._windows = {}
        self._lock = Lock()

    def open_kick(self, slug):
        if not isinstance(slug, str) or slug not in CHANNELS:
            raise ValueError("Unknown Kick channel.")
        with self._lock:
            existing = self._windows.get(slug)
            if existing is not None:
                existing.restore()
                existing.show()
                return
            window = webview.create_window(
                f"Zyvaire | Kick: {CHANNELS[slug]}",
                f"https://kick.com/{slug}",
                width=1180,
                height=790,
                background_color="#151419",
            )
            self._windows[slug] = window

        def forget():
            with self._lock:
                self._windows.pop(slug, None)

        window.events.closed += forget


def main():
    PROFILE.mkdir(parents=True, exist_ok=True)
    webview.settings["ALLOW_DOWNLOADS"] = True
    webview.settings["ALLOW_FILE_URLS"] = False
    handler = partial(LocalAssets, directory=str(ROOT / "app"))
    with ThreadingHTTPServer((ADDRESS, PORT), handler) as server:
        worker = Thread(target=server.serve_forever, daemon=True)
        worker.start()
        webview.create_window(
            "Zyvaire",
            f"http://{ADDRESS}:{PORT}/",
            js_api=KickWindows(),
            width=1420,
            height=840,
            min_size=(600, 550),
            background_color="#151419",
        )
        try:
            webview.start(
                gui="edgechromium",
                private_mode=False,
                storage_path=str(PROFILE),
                icon=str(ROOT / "Zyvaire.ico"),
            )
        finally:
            server.shutdown()
            worker.join()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        log_path = PROFILE.parent / "startup-error.txt"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        log_path.write_text(format_exc(), encoding="utf-8")
        ctypes.windll.user32.MessageBoxW(
            None, f"Zyvaire could not start. Details are in {log_path}", "Zyvaire", 0x10
        )
        raise SystemExit(1)
